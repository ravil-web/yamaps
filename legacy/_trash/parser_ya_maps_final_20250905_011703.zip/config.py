#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# ============================================================================
# КОНФИГУРАЦИЯ ПАРСЕРА YANDEX MAPS
# ============================================================================

# URL для поиска предприятий
SEARCH_URL = "https://yandex.ru/maps/39/rostov-na-donu/search/Ростов%20на%20дону%20суворовский%20стоматология/?ll=39.682860%2C47.325943&sctx=ZAAAAAgCEAAaKAoSCbnEkQci10NAESl4CrlSn0dAEhIJ98ySADW1zj8R1lJA2v8Aqz8iBgABAgMEBSgKOABA0YgGSAFqAnJ1nQHNzMw9oAEAqAEAvQHFGEBwwgEYg7OsgLUByab0le0BxYPspqME3bSJrbMDggJK0KDQvtGB0YLQvtCyINC90LAg0LTQvtC90YMg0YHRg9Cy0L7RgNC%2B0LLRgdC60LjQuSDRgdGC0L7QvNCw0YLQvtC70L7Qs9C40Y%2BKAgCSAgIzOZoCDGRlc2t0b3AtbWFwc9oCKAoSCVa9%2FE6T10NAEYi0VvjBqUdAEhIJAHaopiTrsD8RAOiVsgxxnD%2FgAgE%3D&sll=39.682860%2C47.325943&sspn=0.050086%2C0.021049&z=14.8"

# Количество предприятий для парсинга (0 = все найденные)
TARGET_BUSINESSES_COUNT = 3

# Количество товаров/услуг для каждого предприятия (0 = все найденные)
TARGET_PRODUCTS_COUNT = 30

# Настройки задержек (в секундах)
DELAYS = {
    'page_load': 5,        # Загрузка страницы
    'scroll': 1,           # Прокрутка
    'tab_switch': 3,       # Переключение вкладок
    'element_click': 2,    # Клик по элементу
    'between_businesses': 3  # Между предприятиями
}

# Настройки браузера
BROWSER_OPTIONS = {
    'window_size': '1920,1080',
    'start_maximized': True,
    'disable_logging': True,
    'log_level': 3
}

# Структура папок
FOLDER_STRUCTURE = {
    'base_folder': 'parsing_results',  # Основная папка для результатов
    'businesses_subfolder': 'businesses',  # Подпапка для предприятий
    'logs_subfolder': 'logs'  # Подпапка для логов
}

# Настройки логирования
LOGGING = {
    'level': 'INFO',  # DEBUG, INFO, WARNING, ERROR
    'file_encoding': 'utf-8',
    'include_timestamp': True
}

# Настройки сохранения
SAVE_OPTIONS = {
    'save_json': True,     # Сохранять JSON файлы
    'save_csv': True,      # Сохранять CSV файлы
    'save_products_separate': True,  # Отдельный CSV для товаров
    'include_timestamp': True  # Включать timestamp в имя файла
}

# Настройки обработки ошибок
ERROR_HANDLING = {
    'continue_on_error': True,  # Продолжать при ошибке предприятия
    'max_retries': 3,           # Максимум попыток для одного предприятия
    'save_on_interrupt': True   # Сохранять данные при прерывании
}
