#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Окончательно рабочий парсер Яндекс.Карт
Решает проблемы с кликами и навигацией
"""

import time
import os
import json
import pandas as pd
import re
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains

class FinalWorkingParser:
    """Финальная рабочая версия парсера"""
    
    def __init__(self, target_count=3):
        self.driver = None
        self.wait = None
        self.businesses = []
        self.processed_urls = set()
        self.target_count = target_count
        self.search_url = None
    
    def setup_driver(self):
        """Настройка браузера"""
        print("🚀 Настройка браузера...")
        
        options = Options()
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        options.add_argument('--disable-blink-features=AutomationControlled')
        options.add_experimental_option("excludeSwitches", ["enable-automation"])
        options.add_experimental_option('useAutomationExtension', False)
        options.add_argument('--window-size=1920,1080')
        options.add_argument('--start-maximized')
        
        # Подавление системных ошибок Windows
        options.add_argument('--disable-logging')
        options.add_argument('--log-level=3')
        options.add_argument('--disable-extensions')
        options.add_argument('--disable-default-apps')
        options.add_argument('--disable-component-extensions-with-background-pages')
        options.add_argument('--disable-background-networking')
        options.add_argument('--disable-system-font-check')
        options.add_argument('--disable-component-update')
        options.add_argument('--disable-features=VizDisplayCompositor')
        options.add_argument('--disable-features=TranslateUI')
        
        try:
            self.driver = webdriver.Chrome(options=options)
            self.driver.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
            self.driver.implicitly_wait(5)
            self.wait = WebDriverWait(self.driver, 10)
            print("✅ Браузер запущен")
            return True
        except Exception as e:
            print(f"❌ Ошибка запуска браузера: {e}")
            return False
    
    def navigate_to_search(self, url):
        """Переход на страницу поиска"""
        print(f"📖 Переход на: {url}")
        
        # Проверяем, что URL валидный
        if not url or not url.startswith('http'):
            print(f"❌ Неверный URL: {url}")
            return False
            
        self.search_url = url
        try:
            self.driver.get(url)
            time.sleep(5)
            
            # Проверяем капчу
            if "SmartCaptcha" in self.driver.page_source:
                print("🔒 Обнаружена капча. Ожидание решения...")
                input("Решите капчу и нажмите Enter...")
                time.sleep(3)
            
            print("✅ Страница загружена")
            return True
        except Exception as e:
            print(f"❌ Ошибка загрузки страницы: {e}")
            return False
    
    def get_business_links(self):
        """Получение прямых ссылок на предприятия"""
        print("🔍 Поиск ссылок на предприятия...")
        
        # Прокручиваем страницу для загрузки всех элементов
        self.scroll_to_load_more()
        
        # Ищем прямые ссылки на организации
        try:
            # Ссылки в формате /org/название/id/
            org_links = self.driver.find_elements(By.XPATH, "//a[contains(@href, '/org/') and not(contains(@href, '/gallery/')) and not(contains(@href, '/reviews/')) and not(contains(@href, '/features/'))]")
            
            # Фильтруем только основные ссылки на организации
            main_links = []
            seen_ids = set()
            
            for link in org_links:
                href = link.get_attribute('href')
                if href and '/org/' in href:
                    # Извлекаем ID организации из URL
                    parts = href.split('/org/')
                    if len(parts) > 1:
                        org_part = parts[1].split('/')[1] if len(parts[1].split('/')) > 1 else parts[1]
                        if org_part and org_part.isdigit() and org_part not in seen_ids:
                            seen_ids.add(org_part)
                            main_links.append(href)
            
            print(f"✅ Найдено {len(main_links)} уникальных ссылок на предприятия")
            return main_links
            
        except Exception as e:
            print(f"❌ Ошибка поиска ссылок: {e}")
            return []
    
    def scroll_to_load_more(self):
        """Прокрутка для загрузки больше предприятий"""
        print("📜 Прокрутка для загрузки предприятий...")
        
        last_height = self.driver.execute_script("return document.body.scrollHeight")
        scroll_attempts = 0
        max_scrolls = 5
        
        while scroll_attempts < max_scrolls:
            # Прокручиваем вниз
            self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            time.sleep(3)
            
            # Проверяем, изменилась ли высота страницы
            new_height = self.driver.execute_script("return document.body.scrollHeight")
            if new_height == last_height:
                break
            
            last_height = new_height
            scroll_attempts += 1
            print(f"   Прокрутка {scroll_attempts}/{max_scrolls}")
        
        # Возвращаемся наверх
        self.driver.execute_script("window.scrollTo(0, 0);")
        time.sleep(2)
    
    def navigate_to_business(self, business_url):
        """Переход к карточке предприятия по прямой ссылке"""
        print(f"🎯 Переход к предприятию: {business_url}")
        
        try:
            # Проверяем на дубли
            if business_url in self.processed_urls:
                print("⚠️ Предприятие уже было обработано")
                return False
            
            self.processed_urls.add(business_url)
            
            # Переходим по ссылке
            self.driver.get(business_url)
            time.sleep(4)
            
            # Проверяем, что загрузилась карточка
            try:
                self.wait.until(
                    EC.presence_of_element_located((By.XPATH, "//div[contains(@class, 'business-card-view')]"))
                )
                print("✅ Карточка предприятия загружена")
                return True
            except TimeoutException:
                print("⚠️ Карточка не загрузилась")
                return False
                
        except Exception as e:
            print(f"❌ Ошибка перехода к предприятию: {e}")
            return False
    
    def extract_business_data(self):
        """Извлечение данных из карточки предприятия"""
        print("📊 Извлечение данных...")
        
        data = {
            'name': '',
            'verified': False,
            'categories': [],
            'rating': '',
            'reviews_count': '',
            'awards': [],
            'address': '',
            'phones': [],
            'website': '',
            'social_links': {
                'youtube': '',
                'whatsapp': '',
                'vk': '',
                'ok': '',
                'other': []
            },
            'working_hours': {
                'current_status': '',
                'schedule': []
            },
            'services': [],
            'products': [],
            'features': [],
            'accessibility': {},
            'has_panorama': False,
            'photos_count': 0,
            'stories': [],
            'coordinates': {'lat': '', 'lon': ''},
            'yandex_id': '',
            'url': self.driver.current_url,
            'last_updated': datetime.now().isoformat()
        }
        
        try:
            # НАЗВАНИЕ (из диагностики - рабочие селекторы)
            try:
                name_selectors = [
                    "//h1",  # Простой H1 - работает!
                    "//*[@itemprop='name']",  # Микроразметка - работает!
                    "//meta[@property='og:title']"  # Meta-тег в крайнем случае
                ]
                for selector in name_selectors:
                    try:
                        if 'meta' in selector:
                            name_elem = self.driver.find_element(By.XPATH, selector)
                            full_title = name_elem.get_attribute('content')
                            # Извлекаем только название до первой запятой
                            if full_title and ',' in full_title:
                                data['name'] = full_title.split(',')[0].strip()
                            elif full_title:
                                data['name'] = full_title.strip()
                        else:
                            name_elem = self.driver.find_element(By.XPATH, selector)
                            text = self.safe_get_text(name_elem)
                            if text:
                                data['name'] = text
                        
                        if data['name']:
                            break
                    except:
                        continue
            except:
                pass
            
            # ВЕРИФИКАЦИЯ
            try:
                self.driver.find_element(By.XPATH, "//span[contains(@class, 'business-verified-badge')]")
                data['verified'] = True
            except:
                data['verified'] = False
            
            # КАТЕГОРИИ
            try:
                # Пробуем разные селекторы для категорий
                category_selectors = [
                    "//a[contains(@class, 'business-categories-view__category')]",
                    "//div[contains(@class, 'categories')]//a",
                    "//span[contains(@class, 'category')]"
                ]
                for selector in category_selectors:
                    try:
                        category_elements = self.driver.find_elements(By.XPATH, selector)
                        if category_elements:
                            data['categories'] = [self.safe_get_text(elem) for elem in category_elements if self.safe_get_text(elem)]
                            if data['categories']:
                                break
                    except:
                        continue
            except:
                pass
            
            # РЕЙТИНГ
            try:
                rating_elem = self.driver.find_element(By.XPATH, "//span[contains(@class, 'business-rating-badge-view__rating-text')]")
                data['rating'] = self.safe_get_text(rating_elem)
            except:
                pass
            
            # ОТЗЫВЫ
            try:
                reviews_elem = self.driver.find_element(By.XPATH, "//div[contains(@class, 'business-header-rating-view__text')]")
                reviews_text = self.safe_get_text(reviews_elem)
                numbers = re.findall(r'\((\d+)\)', reviews_text)
                if numbers:
                    data['reviews_count'] = numbers[0]
            except:
                pass
            
            # НАГРАДЫ
            try:
                award_elements = self.driver.find_elements(By.XPATH, "//div[contains(@class, 'business-header-awards-view__award-text')]")
                data['awards'] = [self.safe_get_text(elem) for elem in award_elements if self.safe_get_text(elem)]
            except:
                pass
            
            # АДРЕС
            try:
                address_selectors = [
                    "//div[contains(@class, 'business-contacts-view__address-link')]",
                    "//meta[@itemprop='address']",
                    "//div[contains(@class, 'business-contacts-view__address')]",
                    "//span[contains(@class, 'address')]"
                ]
                for selector in address_selectors:
                    try:
                        if 'meta' in selector:
                            address_elem = self.driver.find_element(By.XPATH, selector)
                            address_text = address_elem.get_attribute('content')
                        else:
                            address_elem = self.driver.find_element(By.XPATH, selector)
                            address_text = self.safe_get_text(address_elem)
                        
                        if address_text:
                            # Очищаем адрес от лишних элементов
                            address_text = address_text.replace('Маршрут', '').replace('Показать входы', '').replace('Маршру', '')
                            address_text = address_text.replace('Маршру', '').replace('Показать', '').replace('входы', '')
                            address_text = address_text.replace('  ', ' ').strip()
                            
                            # Дополнительная очистка от лишних символов
                            import re
                            address_text = re.sub(r'[^\w\s,.-]', '', address_text)  # Оставляем только буквы, цифры, пробелы, запятые, точки, дефисы
                            address_text = re.sub(r'\s+', ' ', address_text).strip()  # Убираем множественные пробелы
                            
                            if address_text and len(address_text) > 5:  # Минимальная длина адреса
                                data['address'] = address_text
                                break
                    except:
                        continue
            except:
                pass
            
            # ТЕЛЕФОНЫ
            try:
                phone_elements = self.driver.find_elements(By.XPATH, "//span[@itemprop='telephone']")
                data['phones'] = [self.safe_get_text(elem) for elem in phone_elements if self.safe_get_text(elem)]
            except:
                pass
            
            # ВЕБ-САЙТ
            try:
                website_elem = self.driver.find_element(By.XPATH, "//a[@itemprop='url']")
                data['website'] = website_elem.get_attribute('href')
            except:
                pass
            
            # СОЦИАЛЬНЫЕ СЕТИ
            try:
                social_elements = self.driver.find_elements(By.XPATH, "//a[@itemprop='sameAs']")
                for social_elem in social_elements:
                    href = social_elem.get_attribute('href')
                    if 'youtube' in href:
                        data['social_links']['youtube'] = href
                    elif 'whatsapp' in href or 'wa.me' in href:
                        data['social_links']['whatsapp'] = href
                    elif 'vk.com' in href:
                        data['social_links']['vk'] = href
                    elif 'ok.ru' in href:
                        data['social_links']['ok'] = href
                    else:
                        data['social_links']['other'].append(href)
            except:
                pass
            
            # ВРЕМЯ РАБОТЫ
            try:
                status_elem = self.driver.find_element(By.XPATH, "//div[contains(@class, 'business-card-working-status-view__text')]")
                data['working_hours']['current_status'] = self.safe_get_text(status_elem)
                
                schedule_metas = self.driver.find_elements(By.XPATH, "//meta[@itemprop='openingHours']")
                data['working_hours']['schedule'] = [meta.get_attribute('content') for meta in schedule_metas]
            except:
                pass
            
            # УСЛУГИ
            try:
                services_elem = self.driver.find_element(By.XPATH, "//span[contains(@class, 'business-features-view__valued-value')]")
                services_text = self.safe_get_text(services_elem)
                if services_text:
                    data['services'] = [s.strip() for s in services_text.split(',')]
            except:
                pass
            
            # ТОВАРЫ И ЦЕНЫ
            try:
                print("   🛍️ Извлечение товаров и услуг...")
                
                # Ищем и переходим на вкладку товаров/услуг
                tab_found = False
                tab_selectors = [
                    "//div[@class='tabs-select-view__title _name_prices']",
                    "//div[contains(@class, 'tabs-select-view__title') and contains(text(), 'Цены')]",
                    "//div[contains(@class, 'tabs-select-view__title') and contains(text(), 'Товары')]",
                    "//div[contains(@class, 'tabs-select-view__title') and contains(text(), 'Услуги')]",
                    "//div[contains(@class, 'tab') and contains(text(), 'Цены')]",
                    "//div[contains(@class, 'tab') and contains(text(), 'Товары')]",
                    "//div[contains(@class, 'tab') and contains(text(), 'Услуги')]",
                    "//a[contains(@href, 'prices')]",
                    "//a[contains(text(), 'Цены')]",
                    "//a[contains(text(), 'Товары')]",
                    "//a[contains(text(), 'Услуги')]"
                ]
                
                for selector in tab_selectors:
                    try:
                        tab_elem = self.driver.find_element(By.XPATH, selector)
                        self.driver.execute_script("arguments[0].click();", tab_elem)
                        time.sleep(2)
                        print(f"   ✅ Перешли на вкладку товаров: {selector}")
                        tab_found = True
                        break
                    except:
                        continue
                
                if not tab_found:
                    print("   ⚠️ Вкладка товаров не найдена, ищем товары на основной странице")
                
                # Агрессивная прокрутка для загрузки всех товаров
                print("   📜 Прокрутка для загрузки товаров...")
                for i in range(5):
                    self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                    time.sleep(1)
                    
                # Дополнительная прокрутка внутри возможных контейнеров
                try:
                    containers = self.driver.find_elements(By.XPATH, "//div[contains(@class, 'scroll')]")
                    for container in containers:
                        for j in range(3):
                            self.driver.execute_script("arguments[0].scrollTop = arguments[0].scrollHeight;", container)
                            time.sleep(0.5)
                except:
                    pass
                
                # Поиск товаров - расширенные селекторы
                print("   🔍 Поиск элементов товаров...")
                product_elems = []
                
                # Сначала пробуем самые точные селекторы
                primary_selectors = [
                    "//div[contains(@class, 'business-full-items-grouped-view__item')]",
                    "//div[contains(@class, 'related-item-photo-view')]",
                    "//div[contains(@class, 'related-item-list-view__item')]", 
                    "//div[contains(@class, 'related-product-view')]"
                ]
                
                for selector in primary_selectors:
                    try:
                        elems = self.driver.find_elements(By.XPATH, selector)
                        if elems:
                            product_elems = elems
                            print(f"   📊 Найдено товаров с основным селектором '{selector}': {len(product_elems)}")
                            break
                    except:
                        continue
                
                # Если не нашли, пробуем дополнительные селекторы
                if not product_elems:
                    additional_selectors = [
                        "//div[contains(@class, 'product-item')]",
                        "//div[contains(@class, 'service-item')]", 
                        "//div[contains(@class, 'price-item')]",
                        "//div[contains(@class, 'menu-item')]",
                        "//div[contains(@class, 'item') and contains(@class, 'related')]",
                        "//div[contains(@class, 'business-item')]",
                        "//div[contains(@class, 'card') and contains(@class, 'item')]",
                        "//li[contains(@class, 'item')]"
                    ]
                    
                    for selector in additional_selectors:
                        try:
                            elems = self.driver.find_elements(By.XPATH, selector)
                            if elems:
                                product_elems = elems
                                print(f"   📊 Найдено товаров с доп. селектором '{selector}': {len(product_elems)}")
                                break
                        except:
                            continue
                    
                # Обрабатываем найденные товары
                if not product_elems:
                    print("   ❌ Товары не найдены")
                    data['products'] = []
                    return data
                    
                print(f"   📊 Обрабатываем {len(product_elems)} товаров...")
                
                # Ограничиваем количество товаров для избежания зависания
                max_products = 50
                if len(product_elems) > max_products:
                    print(f"   ⚠️ Ограничиваем до {max_products} товаров (было {len(product_elems)})")
                    product_elems = product_elems[:max_products]
                
                products = []
                for i, elem in enumerate(product_elems, 1):
                    try:
                        # Показываем прогресс каждые 10 товаров
                        if i % 10 == 0:
                            print(f"   📊 Обработано товаров: {i}/{len(product_elems)}")
                        
                        # Ограничиваем время обработки каждого товара
                        import signal
                        
                        # Название - упрощенные селекторы
                        title = ""
                        title_selectors = [
                            ".//div[contains(@class, 'title')]",
                            ".//span[contains(@class, 'title')]",
                            ".//div[contains(@class, 'name')]",
                            ".//span[contains(@class, 'name')]",
                            ".//h3", ".//h4", ".//h5",
                            ".//a[contains(@class, 'title')]",
                            ".//div[@title]"
                        ]
                        
                        for selector in title_selectors:
                            try:
                                title_elem = elem.find_element(By.XPATH, selector)
                                title = self.safe_get_text(title_elem)
                                if title and len(title) > 2:
                                    break
                            except:
                                continue
                        
                        # Цена - упрощенные селекторы
                        price = ""
                        price_selectors = [
                            ".//span[contains(@class, 'price')]",
                            ".//div[contains(@class, 'price')]",
                            ".//span[contains(@class, 'cost')]",
                            ".//div[contains(@class, 'cost')]",
                            ".//span[contains(@class, 'value')]",
                            ".//span[contains(@class, '₽')]"
                        ]
                        
                        for selector in price_selectors:
                            try:
                                price_elem = elem.find_element(By.XPATH, selector)
                                price = self.safe_get_text(price_elem)
                                if price:
                                    break
                            except:
                                continue
                        
                        # Описание (упрощенное)
                        description = ""
                        try:
                            desc_elem = elem.find_element(By.XPATH, ".//div[contains(@class, 'description')]")
                            description = self.safe_get_text(desc_elem)
                        except:
                            pass
                        
                        # Добавляем товар если есть название
                        if title and len(title) > 2:
                            product_data = {
                                'name': title,
                                'price': price if price else 'Цена не указана',
                                'description': description
                            }
                            products.append(product_data)
                            
                    except Exception as e:
                        if i <= 5:  # Показываем ошибки только для первых 5 товаров
                            print(f"   ⚠️ Ошибка обработки товара {i}: {e}")
                        continue
                
                data['products'] = products
                print(f"   🛍️ Извлечено товаров: {len(products)}")
                
            except Exception as e:
                print(f"   ⚠️ Ошибка извлечения товаров: {e}")
                data['products'] = []
            
            # ОСОБЕННОСТИ
            try:
                feature_elements = self.driver.find_elements(By.XPATH, "//div[contains(@class, 'business-features-view__bool-text')]")
                data['features'] = [self.safe_get_text(elem) for elem in feature_elements if self.safe_get_text(elem)]
            except:
                pass
            
            # ПАНОРАМА
            try:
                self.driver.find_element(By.XPATH, "//button[contains(@class, 'card-media-preview _type_panorama')]")
                data['has_panorama'] = True
            except:
                data['has_panorama'] = False
            
            # ИСТОРИИ
            try:
                story_elements = self.driver.find_elements(By.XPATH, "//div[contains(@class, 'story-preview__title')]")
                data['stories'] = [self.safe_get_text(elem) for elem in story_elements if self.safe_get_text(elem)]
            except:
                pass
            
            # YANDEX ID из URL
            try:
                url_parts = data['url'].split('/')
                for part in url_parts:
                    if part.isdigit() and len(part) > 10:
                        data['yandex_id'] = part
                        break
            except:
                pass
            
            print(f"✅ Данные извлечены: {data['name']}")
            return data
            
        except Exception as e:
            print(f"❌ Ошибка извлечения: {e}")
            return data
    
    def safe_get_text(self, element):
        """Безопасное получение текста"""
        try:
            return element.text.strip() if element else ""
        except:
            return ""
    
    def parse(self, url):
        """Основной метод парсинга"""
        print("🚀 Запуск финального парсера Яндекс.Карт")
        print("=" * 60)
        print(f"🎯 ЦЕЛЬ: {self.target_count} предприятий")
        print("=" * 60)
        
        # Проверяем URL
        if not url or not isinstance(url, str):
            print(f"❌ Неверный URL: {url}")
            return False
        
        if not self.setup_driver():
            return False
        
        if not self.navigate_to_search(url):
            return False
        
        # Получаем ссылки на предприятия
        business_links = self.get_business_links()
        if not business_links:
            print("❌ Не найдены ссылки на предприятия")
            return False
        
        # Ограничиваем до нужного количества
        target_links = business_links[:self.target_count]
        print(f"\n📊 ОБРАБАТЫВАЕМ {len(target_links)} ПРЕДПРИЯТИЙ")
        print("=" * 60)
        
        # Обрабатываем каждое предприятие
        for i, business_url in enumerate(target_links):
            print(f"\n📍 Предприятие {i+1}/{len(target_links)}")
            
            if self.navigate_to_business(business_url):
                business_data = self.extract_business_data()
                
                if business_data and business_data['name']:
                    self.businesses.append(business_data)
                    print(f"✅ Обработано {i+1}/{len(target_links)}: {business_data['name']}")
                    print(f"   📞 Телефонов: {len(business_data['phones'])}")
                    print(f"   🏷️ Категорий: {len(business_data['categories'])}")
                    print(f"   🛍️ Товаров: {len(business_data['products'])}")
                    print(f"   ⭐ Рейтинг: {business_data['rating']}")
                else:
                    print("⚠️ Данные не извлечены")
            else:
                print("❌ Не удалось открыть предприятие")
            
            time.sleep(2)  # Пауза между предприятиями
        
        print(f"\n📈 ПАРСИНГ ЗАВЕРШЕН!")
        print(f"✅ Успешно обработано: {len(self.businesses)} из {len(target_links)}")
        print(f"🎯 Цель ({self.target_count}): {'ДОСТИГНУТА' if len(self.businesses) >= self.target_count else 'НЕ ДОСТИГНУТА'}")
        return True
    
    def save_results(self, project_name=None):
        """Сохранение результатов"""
        if not self.businesses:
            print("❌ Нет данных для сохранения")
            return
        
        os.makedirs("output", exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Используем имя проекта или временную метку
        if project_name:
            base_name = project_name
        else:
            base_name = f"final_data_{timestamp}"
        
        # JSON с полными данными
        json_filename = f"output/{base_name}.json"
        with open(json_filename, 'w', encoding='utf-8') as f:
            json.dump(self.businesses, f, ensure_ascii=False, indent=2)
        print(f"💾 Полные данные: {json_filename}")
        
        # Excel с основными данными
        excel_data = []
        for business in self.businesses:
            row = {
                'Название': business['name'],
                'Верифицирован': 'Да' if business['verified'] else 'Нет',
                'Категории': ', '.join(business['categories']),
                'Рейтинг': business['rating'],
                'Отзывы': business['reviews_count'],
                'Награды': ', '.join(business['awards']),
                'Адрес': business['address'],
                'Телефоны': ', '.join(business['phones']),
                'Сайт': business['website'],
                'WhatsApp': business['social_links']['whatsapp'],
                'VK': business['social_links']['vk'],
                'YouTube': business['social_links']['youtube'],
                'Статус работы': business['working_hours']['current_status'],
                'Услуги': ', '.join(business['services'][:3]),  # Первые 3 услуги
                'Товары': len(business['products']),
                'Панорама': 'Да' if business['has_panorama'] else 'Нет',
                'Истории': len(business['stories']),
                'URL': business['url'],
                'Yandex ID': business['yandex_id']
            }
            excel_data.append(row)
        
        excel_filename = f"output/{base_name}_businesses.xlsx"
        df = pd.DataFrame(excel_data)
        df.to_excel(excel_filename, index=False)
        print(f"📊 Основные данные: {excel_filename}")
        
        # Создаем клиентский HTML дашборд автоматически
        try:
            print("\n🌐 Создание клиентского HTML дашборда...")
            from client_dashboard_generator import ClientDashboardGenerator
            generator = ClientDashboardGenerator()
            dashboard_file = generator.generate_dashboard(json_filename, project_name=project_name)
            if dashboard_file:
                print(f"✅ Клиентский дашборд создан: {dashboard_file}")
                print(f"📁 Дашборд размещен в папке проекта: {os.path.dirname(dashboard_file)}")
                print(f"🌐 Откройте в браузере: {os.path.abspath(dashboard_file)}")
                print(f"📊 Проект: {project_name if project_name else 'Без названия'}")
            else:
                print("❌ Не удалось создать дашборд")
        except ImportError as e:
            print(f"❌ Ошибка импорта клиентского генератора дашборда: {e}")
            print("Убедитесь, что файл client_dashboard_generator.py находится в той же папке")
            # Пробуем современный генератор как fallback
            try:
                print("🔄 Пробуем современный генератор дашборда...")
                from modern_dashboard_generator import ModernDashboardGenerator
                generator = ModernDashboardGenerator()
                dashboard_file = generator.generate_dashboard(json_filename)
                if dashboard_file:
                    print(f"✅ Современный дашборд создан: {dashboard_file}")
            except:
                print("❌ Не удалось создать дашборд")
        except Exception as e:
            print(f"❌ Ошибка создания дашборда: {e}")
            import traceback
            traceback.print_exc()
        
        # Статистика
        print(f"\n📈 СТАТИСТИКА:")
        print(f"   📊 Всего предприятий: {len(self.businesses)}")
        print(f"   📞 С телефонами: {len([b for b in self.businesses if b['phones']])}")
        print(f"   🌐 С сайтами: {len([b for b in self.businesses if b['website']])}")
        print(f"   ✅ Верифицированных: {len([b for b in self.businesses if b['verified']])}")
        print(f"   🏆 С наградами: {len([b for b in self.businesses if b['awards']])}")
        print(f"   📺 С панорамой: {len([b for b in self.businesses if b['has_panorama']])}")
    
    def close(self):
        """Закрытие браузера"""
        if self.driver:
            print("\n👀 Браузер оставлен открытым для анализа")
            print("Нажмите Enter для закрытия...")
            input()
            self.driver.quit()
            print("🔚 Браузер закрыт")

def main():
    """Основная функция"""
    url = "https://yandex.ru/maps/39/rostov-na-donu/search/Ростов%20на%20дону%20суворовский%20стоматология/?ll=39.806284%2C47.275656&sctx=ZAAAAAgCEAAaKAoSCbnEkQci10NAESl4CrlSn0dAEhIJ98ySADW1zj8R1lJA2v8Aqz8iBgABAgMEBSgKOABA0YgGSAFqAnJ1nQHNzMw9oAEAqAEAvQHFGEBwwgElzKy6tfoGxpeW5AXL5fTcA9Ka8PoDwpzMogT4sL%2FgA%2Fyw57rlBoICStCg0L7RgdGC0L7QsiDQvdCwINC00L7QvdGDINGB0YPQstC%2B0YDQvtCy0YHQutC40Lkg0YHRgtC%2B0LzQsNGC0L7Qu9C%2B0LPQuNGPigIAkgICMzmaAgxkZXNrdG9wLW1hcHPaAigKEgnfWbvtQuFDQBGw%2Fs8gd6FHQBISCYBnXaPlQN0%2FEQA8uDtrt7k%2F4AIB&sll=39.806284%2C47.275656&sspn=0.914172%2C0.200856&z=10.61"
    
    target_count = 3  # Тестируем на 3 предприятиях
    
    parser = FinalWorkingParser(target_count=target_count)
    
    try:
        if parser.parse(url):
            parser.save_results()
        
    except KeyboardInterrupt:
        print("\n⏹️ Парсинг остановлен пользователем")
    except Exception as e:
        print(f"❌ Критическая ошибка: {e}")
        import traceback
        traceback.print_exc()
    finally:
        parser.close()

if __name__ == "__main__":
    main()
