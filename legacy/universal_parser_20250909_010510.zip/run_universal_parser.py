#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Основной файл запуска универсального парсера
"""

import sys
import os
import time
from datetime import datetime

# Добавление пути к модулям
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from universal_parser import UniversalParser
from config_universal import (
    TARGET_COUNT, SUPPORTED_PLATFORMS, HEADLESS_MODE,
    EXAMPLE_URLS, YANDEX_MAPS, OZON
)

def print_banner():
    """Вывод баннера"""
    print("=" * 60)
    print("🚀 УНИВЕРСАЛЬНЫЙ ПАРСЕР")
    print("=" * 60)
    print("Поддерживаемые платформы:")
    for platform in SUPPORTED_PLATFORMS:
        print(f"  • {platform}")
    print("=" * 60)

def get_user_input():
    """Получение входных данных от пользователя"""
    print("\n📝 ВВОД ПАРАМЕТРОВ")
    print("-" * 30)
    
    # URL для парсинга
    print("\n🌐 Введите URL для парсинга:")
    print("Примеры:")
    for platform, urls in EXAMPLE_URLS.items():
        print(f"  {platform}:")
        for url in urls[:2]:  # Показываем только первые 2 URL
            print(f"    {url}")
    
    url = input("\nURL: ").strip()
    if not url:
        print("❌ URL не может быть пустым!")
        return None
    
    # Количество элементов
    print(f"\n📊 Количество элементов для парсинга:")
    print(f"  (0 = все найденные, по умолчанию: {TARGET_COUNT})")
    
    try:
        count_input = input("Количество: ").strip()
        if count_input:
            target_count = int(count_input)
        else:
            target_count = TARGET_COUNT
    except ValueError:
        print("⚠️ Неверный формат, используется значение по умолчанию")
        target_count = TARGET_COUNT
    
    # Режим работы
    print(f"\n🖥️ Режим работы браузера:")
    print(f"  (0 = с окном, 1 = без окна, по умолчанию: {int(HEADLESS_MODE)})")
    
    try:
        headless_input = input("Режим (0/1): ").strip()
        if headless_input:
            headless = bool(int(headless_input))
        else:
            headless = HEADLESS_MODE
    except ValueError:
        print("⚠️ Неверный формат, используется значение по умолчанию")
        headless = HEADLESS_MODE
    
    return {
        'url': url,
        'target_count': target_count,
        'headless': headless
    }

def validate_url(url):
    """Проверка URL"""
    if not url.startswith(('http://', 'https://')):
        print("❌ URL должен начинаться с http:// или https://")
        return False
    
    # Проверяем поддерживаемые платформы
    parser = UniversalParser()
    platform = parser.detect_platform(url)
    
    if platform == 'unknown':
        print("⚠️ Неизвестная платформа. Парсинг может не работать корректно.")
        response = input("Продолжить? (y/n): ").strip().lower()
        if response not in ['y', 'yes', 'да', 'д']:
            return False
    
    return True

def print_platform_info(platform):
    """Вывод информации о платформе"""
    print(f"\n🔍 ОПРЕДЕЛЕНА ПЛАТФОРМА: {platform.upper()}")
    print("-" * 30)
    
    if platform == 'yandex_maps':
        print("📋 Настройки Яндекс.Карт:")
        print(f"  • Максимум предприятий: {YANDEX_MAPS['max_businesses']}")
        print(f"  • Попытки прокрутки: {YANDEX_MAPS['scroll_attempts']}")
        print(f"  • Таймаут ожидания: {YANDEX_MAPS['wait_timeout']}с")
    elif platform == 'ozon':
        print("📋 Настройки Ozon:")
        print(f"  • Максимум товаров: {OZON['max_products']}")
        print(f"  • Попытки прокрутки: {OZON['scroll_attempts']}")
        print(f"  • Таймаут ожидания: {OZON['wait_timeout']}с")

def print_results_summary(results, platform, target_count):
    """Вывод сводки результатов"""
    print(f"\n📊 СВОДКА РЕЗУЛЬТАТОВ")
    print("=" * 30)
    
    actual_count = len(results)
    print(f"🎯 Запрошено: {target_count}")
    print(f"✅ Найдено: {actual_count}")
    
    if target_count > 0:
        success_rate = (actual_count / target_count) * 100
        print(f"📈 Успешность: {success_rate:.1f}%")
        
        if actual_count >= target_count:
            print("🎉 ЦЕЛЬ ДОСТИГНУТА!")
        else:
            print(f"⚠️ Цель не достигнута. Не хватает {target_count - actual_count} элементов")
    else:
        print("📋 Парсинг всех найденных элементов завершен")
    
    # Показываем примеры найденных элементов
    if results:
        print(f"\n📋 ПРИМЕРЫ НАЙДЕННЫХ ЭЛЕМЕНТОВ:")
        for i, item in enumerate(results[:5], 1):
            if platform == 'yandex_maps':
                name = item.get('name', 'Без названия')
                address = item.get('address', 'Адрес не указан')
                print(f"   {i}. {name}")
                print(f"      📍 {address}")
            elif platform == 'ozon':
                name = item.get('name', 'Без названия')
                price = item.get('price', 'Цена не указана')
                print(f"   {i}. {name}")
                print(f"      💰 {price}")
        
        if len(results) > 5:
            print(f"   ... и еще {len(results) - 5} элементов")

def main():
    """Основная функция"""
    print_banner()
    
    # Получение параметров от пользователя
    params = get_user_input()
    if not params:
        return
    
    url = params['url']
    target_count = params['target_count']
    headless = params['headless']
    
    # Проверка URL
    if not validate_url(url):
        return
    
    # Определение платформы
    parser = UniversalParser(headless=headless, target_count=target_count)
    platform = parser.detect_platform(url)
    print_platform_info(platform)
    
    # Подтверждение запуска
    print(f"\n🚀 ГОТОВ К ЗАПУСКУ")
    print("-" * 20)
    print(f"URL: {url}")
    print(f"Платформа: {platform}")
    print(f"Количество: {target_count if target_count > 0 else 'все найденные'}")
    print(f"Режим: {'без окна' if headless else 'с окном'}")
    
    response = input("\nЗапустить парсинг? (y/n): ").strip().lower()
    if response not in ['y', 'yes', 'да', 'д']:
        print("❌ Парсинг отменен")
        return
    
    # Запуск парсинга
    print(f"\n🔄 ЗАПУСК ПАРСИНГА")
    print("=" * 30)
    start_time = time.time()
    
    try:
        success = parser.parse(url)
        end_time = time.time()
        duration = end_time - start_time
        
        if success:
            print(f"\n✅ ПАРСИНГ ЗАВЕРШЕН УСПЕШНО!")
            print(f"⏱️ Время выполнения: {duration:.1f} секунд")
            
            # Вывод сводки результатов
            print_results_summary(parser.results, platform, target_count)
            
            # Сохранение результатов
            if parser.results:
                print(f"\n💾 СОХРАНЕНИЕ РЕЗУЛЬТАТОВ")
                print("-" * 25)
                save_success = parser.save_results()
                if save_success:
                    print("✅ Результаты сохранены")
                else:
                    print("❌ Ошибка сохранения результатов")
        else:
            print(f"\n❌ ПАРСИНГ ЗАВЕРШИЛСЯ С ОШИБКАМИ")
            print(f"⏱️ Время выполнения: {duration:.1f} секунд")
    
    except KeyboardInterrupt:
        print(f"\n⚠️ ПАРСИНГ ПРЕРВАН ПОЛЬЗОВАТЕЛЕМ")
        if parser.results:
            print("💾 Сохранение частичных результатов...")
            parser.save_results()
    except Exception as e:
        print(f"\n❌ КРИТИЧЕСКАЯ ОШИБКА: {e}")
        import traceback
        traceback.print_exc()
    finally:
        parser.close()
    
    print(f"\n👋 РАБОТА ЗАВЕРШЕНА")
    print("=" * 30)

if __name__ == "__main__":
    main()
