#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Генератор клиентского дашборда в стиле Bootstrap
Создает дашборд с навигацией по страницам и статистическими карточками
"""

import json
import os
import re
from datetime import datetime
from pathlib import Path
from collections import defaultdict

class ClientDashboardGenerator:
    """Генератор клиентского дашборда"""
    
    def __init__(self):
        self.css_styles = """
        <style>
            body {
                background-color: #f8f9fa;
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            }
            .card {
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                border: none;
                border-radius: 10px;
                transition: transform 0.2s;
            }
            .card:hover {
                transform: translateY(-5px);
            }
            .card-title {
                font-size: 2rem;
                font-weight: bold;
            }
            .stats-card {
                cursor: pointer;
            }
            .chart-container {
                background: white;
                border-radius: 10px;
                padding: 20px;
                margin-bottom: 20px;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            }
            .table {
                background: white;
                border-radius: 10px;
                overflow: hidden;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            }
            .header {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                padding: 30px 0;
                margin-bottom: 30px;
            }
            .page {
                display: none;
            }
            .page.active {
                display: block;
            }
            .nav-link {
                color: #495057;
                font-weight: 500;
            }
            .nav-link.active {
                color: #007bff !important;
                font-weight: bold;
            }
            .back-btn {
                margin-bottom: 20px;
            }
        </style>
        """
        
        self.javascript = """
        <script>
            function showPage(pageId) {
                // Скрываем все страницы
                document.querySelectorAll('.page').forEach(page => {
                    page.classList.remove('active');
                });
                
                // Показываем выбранную страницу
                document.getElementById(pageId).classList.add('active');
            }
            
            function showBusinessProducts(businessName) {
                // Переходим на страницу товаров
                showPage('products-page');
                
                // Находим аккордеон для конкретного предприятия
                setTimeout(function() {
                    var accordionItems = document.querySelectorAll('.accordion-item');
                    accordionItems.forEach(function(item) {
                        var button = item.querySelector('.accordion-button');
                        if (button && button.textContent.includes(businessName)) {
                            // Кликаем по кнопке для открытия
                            button.click();
                        }
                    });
                }, 100);
            }
            
            // Простая функция для переключения аккордеона
            function toggleAccordion(button) {
                var target = button.getAttribute('data-target');
                var targetElement = document.querySelector(target);
                var parentAccordion = button.closest('.accordion');
                
                if (!targetElement) return;
                
                // Проверяем текущее состояние
                var isOpen = targetElement.classList.contains('show');
                
                if (isOpen) {
                    // Закрываем
                    targetElement.classList.remove('show');
                    button.classList.add('collapsed');
                    button.setAttribute('aria-expanded', 'false');
                } else {
                    // Закрываем все другие в этом аккордеоне
                    if (parentAccordion) {
                        parentAccordion.querySelectorAll('.accordion-collapse.show').forEach(function(element) {
                            element.classList.remove('show');
                        });
                        parentAccordion.querySelectorAll('.accordion-button').forEach(function(btn) {
                            btn.classList.add('collapsed');
                            btn.setAttribute('aria-expanded', 'false');
                        });
                    }
                    
                    // Открываем текущий
                    targetElement.classList.add('show');
                    button.classList.remove('collapsed');
                    button.setAttribute('aria-expanded', 'true');
                }
            }
            
            // Инициализация при загрузке страницы
            document.addEventListener('DOMContentLoaded', function() {
                // Добавляем обработчики для всех кнопок аккордеона
                document.addEventListener('click', function(e) {
                    if (e.target.classList.contains('accordion-button')) {
                        e.preventDefault();
                        e.stopPropagation();
                        toggleAccordion(e.target);
                    }
                });
                
                // Дополнительная инициализация для надежности
                setTimeout(function() {
                    var buttons = document.querySelectorAll('.accordion-button');
                    buttons.forEach(function(button) {
                        button.addEventListener('click', function(e) {
                            e.preventDefault();
                            e.stopPropagation();
                            toggleAccordion(this);
                        });
                    });
                }, 100);
            });
        </script>
        """
    
    def generate_businesses_table(self, businesses):
        """Генерация таблицы предприятий"""
        if not businesses:
            return '<p>Предприятия не найдены</p>'
        
        table_html = '''
        <table border="1" class="dataframe table table-striped table-bordered table-hover">
        <thead>
            <tr style="text-align: right;">
                <th>Название</th>
                <th>Рейтинг</th>
                <th>Адрес</th>
                <th>Телефоны</th>
                <th>Категории</th>
                <th>Товары/услуги</th>
                <th>Отзывы</th>
                <th>Ссылки</th>
            </tr>
        </thead>
        <tbody>
        '''
        
        for business in businesses:
            name = business.get('name', 'Не указано')
            rating = business.get('rating', 'Нет оценок')
            
            # Исправляем отображение адреса
            address = business.get('address', '')
            
            # Очищаем адрес от лишних элементов
            if address:
                # Убираем лишние элементы из адреса
                address = address.replace('Маршрут', '').replace('Показать входы', '').replace('Маршру', '')
                address = address.replace('Маршру', '').replace('Показать', '').replace('входы', '')
                address = address.replace('  ', ' ').strip()  # Убираем двойные пробелы
                
                # Дополнительная очистка от лишних символов
                address = re.sub(r'[^\w\s,.-]', '', address)  # Оставляем только буквы, цифры, пробелы, запятые, точки, дефисы
                address = re.sub(r'\s+', ' ', address).strip()  # Убираем множественные пробелы
                
                # Если адрес стал пустым после очистки или слишком короткий
                if not address or len(address) < 3:
                    address = 'Не указан'
            else:
                # Пробуем получить адрес из разных источников
                working_hours = business.get('working_hours', {})
                if working_hours:
                    address = working_hours.get('current_status', '')
                    if address:
                        # Очищаем и этот адрес
                        address = address.replace('Маршрут', '').replace('Показать входы', '').replace('Маршру', '')
                        address = address.replace('  ', ' ').strip()
                    
                    if not address and working_hours.get('schedule'):
                        address = working_hours['schedule'][0] if working_hours['schedule'] else ''
                        if address:
                            address = address.replace('Маршрут', '').replace('Показать входы', '').replace('Маршру', '')
                            address = address.replace('  ', ' ').strip()
                
                if not address:
                    # Пробуем получить из URL
                    url = business.get('url', '')
                    if url and 'maps' in url:
                        address = 'Адрес в Яндекс.Картах'
                    else:
                        address = 'Не указан'
            
            # Создаем кликабельные ссылки для телефонов
            phone_list = business.get('phones', [])
            if phone_list:
                phone_links = []
                for phone in phone_list:
                    # Очищаем номер от лишних символов для tel: ссылки
                    clean_phone = phone.replace(' ', '').replace('-', '').replace('(', '').replace(')', '')
                    phone_links.append(f'<a href="tel:{clean_phone}" class="btn btn-sm btn-outline-info">📞 {phone}</a>')
                phones = ' '.join(phone_links)
            else:
                phones = 'Не указаны'
            categories = ', '.join(business.get('categories', [])) if business.get('categories') else 'Не указаны'
            products_count = len(business.get('products', []))
            reviews_count = business.get('reviews_count', '0')
            website = business.get('website', '') if business.get('website') else ''
            
            # Создаем кликабельную ссылку для сайта
            if website and website.startswith('http'):
                website_link = f'<a href="{website}" target="_blank" class="btn btn-sm btn-outline-primary">🌐 Сайт</a>'
            else:
                website_link = 'Не указан'
            
            # Создаем кликабельную ссылку для Яндекс.Карт
            yandex_url = business.get('url', '')
            if yandex_url and 'maps' in yandex_url:
                yandex_link = f'<a href="{yandex_url}" target="_blank" class="btn btn-sm btn-outline-success">🗺️ Карты</a>'
            else:
                yandex_link = 'Не указан'
            
            table_html += f'''
            <tr>
                <td>{name}</td>
                <td>{rating}</td>
                <td>{address}</td>
                <td>{phones}</td>
                <td>{categories}</td>
                <td>{products_count}</td>
                <td>{reviews_count}</td>
                <td>{website_link} {yandex_link}</td>
            </tr>
            '''
        
        table_html += '</tbody></table>'
        return table_html
    
    def generate_businesses_list(self, businesses):
        """Генерация компактного списка предприятий для главной страницы"""
        if not businesses:
            return '<p>Предприятия не найдены</p>'
        
        list_html = '''
        <div class="row">
        '''
        
        for business in businesses:
            name = business.get('name', 'Не указано')
            rating = business.get('rating', 'Нет оценок')
            products_count = len(business.get('products', []))
            
            # Создаем кликабельную ссылку для количества товаров конкретного предприятия
            business_name_escaped = name.replace("'", "\\'").replace('"', '\\"')
            products_link = f'<a href="#" onclick="showBusinessProducts(\'{business_name_escaped}\'); return false;" class="btn btn-sm btn-outline-primary">{products_count}</a>'
            
            # Создаем кликабельные ссылки для телефонов
            phone_list = business.get('phones', [])
            if phone_list:
                phone_links = []
                for phone in phone_list:
                    clean_phone = phone.replace(' ', '').replace('-', '').replace('(', '').replace(')', '')
                    phone_links.append(f'<a href="tel:{clean_phone}" class="btn btn-sm btn-outline-info">📞 {phone}</a>')
                phones = ' '.join(phone_links)
            else:
                phones = 'Не указаны'
            
            # Создаем кликабельные ссылки для сайта и карт
            website = business.get('website', '')
            if website and website.startswith('http'):
                website_link = f'<a href="{website}" target="_blank" class="btn btn-sm btn-outline-primary">🌐 Сайт</a>'
            else:
                website_link = ''
            
            yandex_url = business.get('url', '')
            if yandex_url and 'maps' in yandex_url:
                yandex_link = f'<a href="{yandex_url}" target="_blank" class="btn btn-sm btn-outline-success">🗺️ Карты</a>'
            else:
                yandex_link = ''
            
            list_html += f'''
            <div class="col-md-6 col-lg-4 mb-3">
                <div class="card h-100">
                    <div class="card-body">
                        <h5 class="card-title">{name}</h5>
                        <p class="card-text">
                            <strong>Рейтинг:</strong> {rating}<br>
                            <strong>Товаров/услуг:</strong> {products_link}<br>
                            <strong>Телефоны:</strong> {phones}
                        </p>
                        <div class="d-flex gap-2">
                            {website_link}
                            {yandex_link}
                        </div>
                    </div>
                </div>
            </div>
            '''
        
        list_html += '</div>'
        return list_html
    
    def generate_products_table(self, businesses):
        """Генерация аккордеона товаров по предприятиям с сравнением"""
        if not businesses:
            return '<p>Товары и услуги не найдены</p>'
        
        # Группируем товары для сравнения
        product_groups = defaultdict(list)
        for business in businesses:
            for product in business.get('products', []):
                product_name = product.get('name', '').lower().strip()
                if product_name:
                    product_groups[product_name].append({
                        'business': business.get('name', 'Неизвестно'),
                        'price': product.get('price', 'Цена не указана'),
                        'description': product.get('description', '')
                    })
        
        # Находим товары для сравнения (есть у нескольких предприятий)
        comparison_products = {name: offers for name, offers in product_groups.items() if len(offers) > 1}
        
        accordion_html = '''
        <div class="accordion" id="productsAccordion">
        '''
        
        # Сначала показываем сравнение товаров
        if comparison_products:
            accordion_html += f'''
            <div class="accordion-item">
                <h2 class="accordion-header" id="heading-comparison">
                    <button class="accordion-button collapsed" type="button" data-target="#collapse-comparison" aria-expanded="false" aria-controls="collapse-comparison">
                        <strong>🔄 Сравнение товаров и услуг</strong> - {len(comparison_products)} групп для сравнения
                    </button>
                </h2>
                <div id="collapse-comparison" class="accordion-collapse collapse" aria-labelledby="heading-comparison">
                    <div class="accordion-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>Товар/услуга</th>
                                        <th>Предприятие</th>
                                        <th>Цена</th>
                                        <th>Описание</th>
                                    </tr>
                                </thead>
                                <tbody>
            '''
            
            for product_name, offers in comparison_products.items():
                for i, offer in enumerate(offers):
                    accordion_html += f'''
                                    <tr>
                                        <td><strong>{product_name.title()}</strong></td>
                                        <td>{offer['business']}</td>
                                        <td>{offer['price']}</td>
                                        <td>{offer['description']}</td>
                                    </tr>
                    '''
                    if i < len(offers) - 1:  # Добавляем разделитель между предприятиями
                        accordion_html += '<tr><td colspan="4" style="height: 5px; background: #f8fafc;"></td></tr>'
                # Добавляем разделитель между группами товаров
                accordion_html += '<tr><td colspan="4" style="height: 10px; background: #e9ecef;"></td></tr>'
            
            accordion_html += '''
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            '''
        
        # Затем показываем товары по предприятиям
        for i, business in enumerate(businesses):
            business_name = business.get('name', 'Неизвестно')
            products = business.get('products', [])
            
            if not products:
                continue
            
            accordion_html += f'''
            <div class="accordion-item">
                <h2 class="accordion-header" id="heading{i}">
                    <button class="accordion-button collapsed" type="button" data-target="#collapse{i}" aria-expanded="false" aria-controls="collapse{i}">
                        <strong>{business_name}</strong> - {len(products)} товаров/услуг
                    </button>
                </h2>
                <div id="collapse{i}" class="accordion-collapse collapse" aria-labelledby="heading{i}">
                    <div class="accordion-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>Название товара</th>
                                        <th>Цена</th>
                                        <th>Описание</th>
                                    </tr>
                                </thead>
                                <tbody>
            '''
            
            for product in products:
                name = product.get('name', 'Без названия')
                price = product.get('price', 'Цена не указана')
                description = product.get('description', '')
                
                accordion_html += f'''
                                    <tr>
                                        <td><strong>{name}</strong></td>
                                        <td>{price}</td>
                                        <td>{description}</td>
                                    </tr>
                '''
            
            accordion_html += '''
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            '''
        
        accordion_html += '</div>'
        return accordion_html
    
    def generate_comparison_content(self, businesses):
        """Генерация контента для сравнения товаров с аккордеоном"""
        # Группируем товары по названиям
        product_groups = defaultdict(list)
        
        for business in businesses:
            for product in business.get('products', []):
                product_name = product.get('name', '').lower().strip()
                if product_name:
                    product_groups[product_name].append({
                        'business': business.get('name', 'Неизвестно'),
                        'price': product.get('price', 'Цена не указана'),
                        'description': product.get('description', '')
                    })
        
        # Фильтруем только группы для сравнения
        comparison_groups = {name: offers for name, offers in product_groups.items() if len(offers) > 1}
        
        if not comparison_groups:
            return '<div class="alert alert-info">Похожие услуги не найдены</div>'
        
        # Создаем аккордеон для каждой группы товаров
        accordion_html = '''
        <div class="accordion" id="comparisonAccordion">
        '''
        
        for i, (product_name, offers) in enumerate(comparison_groups.items()):
            accordion_html += f'''
            <div class="accordion-item">
                <h2 class="accordion-header" id="comparison-heading{i}">
                    <button class="accordion-button collapsed" type="button" data-target="#comparison-collapse{i}" aria-expanded="false" aria-controls="comparison-collapse{i}">
                        <strong>{product_name.title()}</strong> - {len(offers)} предложений
                    </button>
                </h2>
                <div id="comparison-collapse{i}" class="accordion-collapse collapse" aria-labelledby="comparison-heading{i}">
                    <div class="accordion-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>Предприятие</th>
                                        <th>Цена</th>
                                        <th>Описание</th>
                                    </tr>
                                </thead>
                                <tbody>
            '''
            
            for offer in offers:
                accordion_html += f'''
                                    <tr>
                                        <td><strong>{offer['business']}</strong></td>
                                        <td>{offer['price']}</td>
                                        <td>{offer['description']}</td>
                                    </tr>
                '''
            
            accordion_html += '''
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            '''
        
        accordion_html += '</div>'
        return accordion_html
    
    def generate_dashboard(self, json_file_path, output_dir=None, project_name=None):
        """Генерация полного HTML дашборда"""
        try:
            # Загружаем данные
            with open(json_file_path, 'r', encoding='utf-8') as f:
                businesses = json.load(f)
            
            if not businesses:
                print("❌ Нет данных для создания дашборда")
                return None
            
            # Определяем папку для сохранения (в корне проекта)
            if output_dir is None:
                output_dir = Path.cwd()  # Текущая папка проекта
            
            # Создаем папку dashboard в корне проекта
            dashboard_dir = output_dir / "dashboard"
            os.makedirs(dashboard_dir, exist_ok=True)
            
            # Статистика
            total_businesses = len(businesses)
            total_products = sum(len(b.get('products', [])) for b in businesses)
            total_reviews = sum(int(b.get('reviews_count', 0)) for b in businesses if str(b.get('reviews_count', '')).isdigit())
            
            # Группируем товары для подсчета групп сравнения
            product_groups = defaultdict(list)
            for business in businesses:
                for product in business.get('products', []):
                    product_name = product.get('name', '').lower().strip()
                    if product_name:
                        product_groups[product_name].append(business.get('name', 'Неизвестно'))
            
            comparison_groups = len([group for group in product_groups.values() if len(group) > 1])
            
            # Генерируем контент для страниц
            businesses_table = self.generate_businesses_table(businesses)
            products_table = self.generate_products_table(businesses)
            comparison_content = self.generate_comparison_content(businesses)
            
            # Полный HTML
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            html_content = f"""
            <!DOCTYPE html>
            <html lang="ru">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>💰 Сравнение цен на стоматологические услуги</title>
                <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
                <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
                <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
                {self.css_styles}
            </head>
            <body>
                <div class="header">
                    <div class="container">
                        <h1 class="text-center mb-0">💰 Сравнение цен на стоматологические услуги</h1>
                        <p class="text-center mb-0 mt-2">Сгенерировано: {timestamp}</p>
                    </div>
                </div>

                <!-- Главная страница -->
                <div id="main-page" class="page active">
                    <div class="container">
                        <!-- Статистические карточки -->
                        <div class="row mb-4">
                            <div class="col-md-4">
                                <div class="card stats-card text-white bg-primary" onclick="showPage('businesses-page')">
                                    <div class="card-body text-center">
                                        <h4 class="card-title">{total_businesses}</h4>
                                        <p class="card-text">Предприятий</p>
                                        <small>Нажмите для просмотра списка</small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card stats-card text-white bg-info" onclick="showPage('products-page')">
                                    <div class="card-body text-center">
                                        <h4 class="card-title">{total_products}</h4>
                                        <p class="card-text">Услуг всего</p>
                                        <small>Нажмите для просмотра по предприятиям</small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card stats-card text-white bg-success" onclick="showPage('comparison-page')">
                                    <div class="card-body text-center">
                                        <h4 class="card-title">{comparison_groups}</h4>
                                        <p class="card-text">Групп для сравнения</p>
                                        <small>Нажмите для просмотра сравнения</small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card stats-card text-white bg-warning" onclick="showPage('reviews-page')">
                                    <div class="card-body text-center">
                                        <h4 class="card-title">{total_reviews}</h4>
                                        <p class="card-text">Отзывов</p>
                                        <small>Нажмите для просмотра отзывов</small>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Список предприятий на главной странице -->
                        <div class="row mt-4">
                            <div class="col-12">
                                <h3 class="mb-3">🏢 Список предприятий</h3>
                                <div class="chart-container">
                                    {self.generate_businesses_list(businesses)}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Страница предприятий -->
                <div id="businesses-page" class="page">
                    <div class="container">
                        <button class="btn btn-secondary back-btn" onclick="showPage('main-page')">
                            ← Назад к главной странице
                        </button>
                        <h2>📋 Список всех предприятий</h2>
                        <div class="chart-container">
                            {businesses_table}
                        </div>
                    </div>
                </div>

                <!-- Страница товаров -->
                <div id="products-page" class="page">
                    <div class="container">
                        <button class="btn btn-secondary back-btn" onclick="showPage('main-page')">
                            ← Назад к главной странице
                        </button>
                        <h2>🛍️ Товары и услуги</h2>
                        <div class="chart-container">
                            {products_table}
                        </div>
                    </div>
                </div>

                <!-- Страница сравнения товаров -->
                <div id="comparison-page" class="page">
                    <div class="container">
                        <button class="btn btn-secondary back-btn" onclick="showPage('main-page')">
                            ← Назад к главной странице
                        </button>
                        <h2>🔄 Сравнение товаров и услуг</h2>
                        <div class="chart-container">
                            {comparison_content}
                        </div>
                    </div>
                </div>

                <!-- Страница отзывов -->
                <div id="reviews-page" class="page">
                    <div class="container">
                        <button class="btn btn-secondary back-btn" onclick="showPage('main-page')">
                            ← Назад к главной странице
                        </button>
                        <h2>💬 Отзывы о предприятиях</h2>
                        <div class="chart-container">
                            <p>Отзывы не найдены</p>
                        </div>
                    </div>
                </div>

                <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
                {self.javascript}
            </body>
            </html>
            """
            
            # Сохраняем файл
            if project_name:
                base_name = project_name
            else:
                base_name = Path(json_file_path).stem
            output_file = os.path.join(dashboard_dir, f"client_dashboard_{base_name}.html")
            
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(html_content)
            
            print(f"✅ Клиентский дашборд создан: {output_file}")
            print(f"📊 Статистика:")
            print(f"   🏢 Предприятий: {total_businesses}")
            print(f"   🛍️ Товаров: {total_products}")
            print(f"   ⚖️ Групп для сравнения: {comparison_groups}")
            print(f"   💬 Отзывов: {total_reviews}")
            
            return output_file
            
        except Exception as e:
            print(f"❌ Ошибка создания дашборда: {e}")
            import traceback
            traceback.print_exc()
            return None

def main():
    """Основная функция"""
    import glob
    
    # Ищем JSON файлы с результатами парсинга
    json_files = glob.glob("output/*.json")
    
    if not json_files:
        print("❌ Не найдены JSON файлы с результатами парсинга")
        print("Запустите парсер сначала")
        return
    
    generator = ClientDashboardGenerator()
    
    for json_file in json_files:
        print(f"\n📊 Создание клиентского дашборда для: {json_file}")
        dashboard_file = generator.generate_dashboard(json_file)
        
        if dashboard_file:
            print(f"🌐 Откройте в браузере: {dashboard_file}")

if __name__ == "__main__":
    main()
